# PRO2_demos_mg1
Alle demo's gegeven door HNR tijdens de PRO2 lessen in blok 2

Blok 2

* B2L1: Functions and Arguments
* B2L2: Classes, Instances, Methods and Constructors
* B2L3: Getters and Setters


Instructies:

Roep vanuit de Main class (Main.java) de demo aan als je deze wil testen.

Bijvoorbeeld: *B2L3_getters_setters.main();* of *B2L1_functions_arguments.main();*
