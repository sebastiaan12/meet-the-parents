public class adult extends Student {
    private boolean can_cook;
    public void setcan_cook(boolean can_cook) {
        this.can_cook = can_cook;
    }
    public boolean getcan_cook() {
        return can_cook;
    }
}

