

public class B2L4_inheritance {
    public static void main(String[] args){


        Student s1 = new Student();
        s1.setName("mark");

        Teacher t1 = new Teacher();
        t1.setName("willem");

        Parent Pt = new Parent();
        Pt.setName("pieter");
        Pt.setvote(true);
        Pt.getvote();

        adult at = new adult();
        at.setName("Sebastiaan");
        at.setcan_cook(false);
        at.getcan_cook();

        Trainer tr1 = new Trainer();
        tr1.setName("evert");
        tr1.setSubject("programeren");

        System.out.println("\033[1;70m"+"hallo! " );

        Person p1 = new Person();
        p1.setName("freekje");




        Person[] people = {
                new Teacher(),
                new Student()

        };
        Teacher t = (Teacher)people[0];
        t.setName("Erwin");
        t.setIq(13);
        t.addDiploma("HBO gamedesign & Development HKU");

        Student s = (Student)people[1];
        s.setName("willem");
        s.setIq(13);
        s.addCourse("PRO2");
        s.addDiploma("VMBO T");

        for (Person person : people) {
            System.out.println("de volwassende heet " + at.getName() + " en kan " + at.getcan_cook() + " koken" );
            System.out.println("De ouder heet " + Pt.getName() + " en stemt " + Pt.getvote() + " stemmen." );
            System.out.println(person.getName() + " heeft een iq van " + person.getIq() + " en heeft deze diplomas" + person.getDiplomas());

        }

    }
}
