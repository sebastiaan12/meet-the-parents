public class Parent extends Person {
    private boolean vote;

    public void setvote(boolean vote) {
        this.vote = vote;
    }
    public boolean getvote() {
        return vote;
    }
}