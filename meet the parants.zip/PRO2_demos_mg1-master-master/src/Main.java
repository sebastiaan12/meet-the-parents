public class Main {

    public static void main(String[] args) {

        //hier de class aanroepen die je wil testen.

        B2L4_inheritance.main(args);

    }
}
